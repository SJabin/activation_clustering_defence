"""
Module implementing detector-based defences against adversarial attacks.
"""
from art.defences.detector import evasion
from art.defences.detector import poison
